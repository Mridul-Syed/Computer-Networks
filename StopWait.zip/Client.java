import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.io.*;
import java.math.BigInteger;

public class Client {

    public static void main(String[] args) {

        try {
        	
            Socket soc = new Socket("localhost", 1234);

            ObjectInputStream sin = new ObjectInputStream(soc.getInputStream());//object input neyar jonno dorkar
            ObjectOutputStream sout = new ObjectOutputStream(soc.getOutputStream());////object pathanor neyar jonno dorkar
            
            
            
            String data="RUET";// eita string type
            int protocolID=16;// eita int type
            boolean tailer;// eitar parity checking er jonno
            double acknowledgement = 0;//eita any type, double er func paisi tai double nisi. float pai nai.
           
         
           //ei duita shob object a same pathabo. tai loop er baire rakhsi
           String dataToByteToString = new String(data.getBytes());// eita data re bytes then string a cnvrt kore
           String protocolIdToBinaryToString= new String(Integer.toBinaryString(protocolID)); // eita data re binary then string a cnvrt kore

           
            System.out.println("Sending object to server...");
            System.out.print("\n\n");
            
            for(int i=1; i<=10; i++) {
            //header change hobe. ek ek kore increase korbe, tai loop er vitore
            double header= i;
            String headerToBinaryToString=new String(Long.toBinaryString(Double.doubleToRawLongBits(header)));// Allah malum. khuija tuija eita e paisi. r pai na 
            
            String TotalBits=headerToBinaryToString+dataToByteToString+protocolIdToBinaryToString;
            
            int numberOfOne=checkOne(TotalBits);
            
            if(numberOfOne%2==0)
                tailer=false;
            else
                tailer=true;
            	
            	
            Frame outFrame = new Frame(i, data, protocolID, tailer, acknowledgement);
            sout.writeObject(outFrame);
            
            System.out.println("Header: " + outFrame.header + "\nData: " + outFrame.data + "\nProtocolID: " + outFrame.protocolID + "\nTailer: " + outFrame.tailer);
            System.out.println();
            System.out.println("Sent frame "+i+" successfully");
            System.out.println();
            System.out.println();
            
            System.out.println("Acknowledgement checking...");
            Frame inFrame = (Frame) sin.readObject();
            double ac = inFrame.acknowledgement ;
            
            System.out.println("Received "+ ac +  " number Frame Successfully");
            System.out.println();
            System.out.println();
              } 

            soc.close();
        } catch (Exception e) {
          System.out.println("Exception caught: " + e);
        }
    }

    static int checkOne(String str) {
        int count = 0;
        for (int i = 0; i < str.length();i++) {
            if(str.charAt(i)=='1')
                count++;
        }
        return count;
    }

}
