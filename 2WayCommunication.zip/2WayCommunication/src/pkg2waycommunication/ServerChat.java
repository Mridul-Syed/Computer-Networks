// Server2 class that 
// receives data and sends data 

import java.io.*; 
import java.net.*; 

class ServerChat { 

	public static void main(String args[]) 
		throws Exception 
	{ 

		
		ServerSocket ss = new ServerSocket(888); 

		System.out.println("Server is ready to chat..."); 
		Socket s = ss.accept(); 
		

		// to send data to the client 
		PrintStream ps 
			= new PrintStream(s.getOutputStream()); 

		
		BufferedReader br 
			= new BufferedReader( 
				new InputStreamReader( 
					s.getInputStream())); 

		
		BufferedReader kb 
			= new BufferedReader( 
				new InputStreamReader(System.in)); 

		
		while (true) { 

			String str, str1; 

			
			while ((str = br.readLine()) != null) { 
				System.out.println(str); 
				str1 = kb.readLine(); 

				
				ps.println(str1); 
			} 

			
			ps.close(); 
			br.close(); 
			kb.close(); 
			ss.close(); 
			s.close(); 

			System.exit(0); 

		} 
	} 
} 
