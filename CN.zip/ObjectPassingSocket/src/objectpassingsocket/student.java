import java.io.Serializable;
class student implements Serializable
 {
   int id;
   String name;
   String course;
   student(int id,String name,String course)
    {
     this.id=id;
     this.name=name;
     this.course=course;
    }
   void showDetails()
    {
     System.out.println("Id:"+id);
     System.out.println("Name:"+name);
     System.out.println("Course:"+course);
    }  
 }