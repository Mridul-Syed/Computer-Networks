import java.net.*;
import java.io.*;
class objectServer
 {
  public static void main(String arg[]) throws Exception
   {
  
   // Server will be started on 1700 port number
    ServerSocket server=new ServerSocket(1700);
	
   // Server listening for connection
    Socket s=server.accept();
	
   // Stream object for sending object 
    ObjectOutputStream os=new ObjectOutputStream(s.getOutputStream());
	
   student object1=new student(1603016,"Mridul","CSE");
   os.writeObject(object1);
   
   s.close();
   }
 }