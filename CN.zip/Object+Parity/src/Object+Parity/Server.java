import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.*;

public class Server {

    public static void main (String[] args) {

        try {
            ServerSocket ser = new ServerSocket(25);
            System.out.println("Waiting..");
            Socket soc = ser.accept();
            System.out.println("Established");

            //BufferedReader in = new BufferedReader(new InputStreamReader(System.in)); //from System
            ObjectOutputStream cout = new ObjectOutputStream(soc.getOutputStream()); //to client
            ObjectInputStream cin = new ObjectInputStream(soc.getInputStream()); //from client

            //receiving from client
            System.out.println("Receiving object from client...");
            Frame inFrame = (Frame) cin.readObject();
            System.out.println("Header: " + inFrame.header + "\nData  " + inFrame.data + "\nProtocolID: " + inFrame.protocolID + "\nTailer: " + inFrame.tailer);
            System.out.println("Received.");
            System.out.println();

            //sending to client
            //Frame outFrame = inFrame;
            //System.out.println("Resending object to client...");
            //cout.writeObject(outFrame);
            //System.out.println(outFrame.header + " " + outFrame.data + " " + outFrame.protocolID + " " + outFrame.tailer);
            //System.out.println("Sent.");
            //System.out.println();

            String tmp_str = Float.toString(inFrame.header);
            String[] tmp_str_2 = tmp_str.split("[.]");
            int count = setBitsInt(inFrame.protocolID) + setBitsStr(inFrame.data) + setBitsInt(Integer.parseInt(tmp_str_2[0])) + setBitsInt(Integer.parseInt(tmp_str_2[1]));

            Boolean temp = true;
            System.out.println("Total number of set bits: " + count);
            if (count % 2 == 0) {
              temp = false;
            }

            if (Boolean.compare(inFrame.tailer, temp) == 0){
              System.out.println("Data is unchanged.");
            } else {
              System.out.println("Data is changed.");
            }
            ser.close();
        } catch (Exception e) {
          System.out.println("Exception caught: " + e);
        }
    }

    static int setBitsInt(int n) {
        int count = 0;
        while (n != 0) {
            if (n > 0) {
                count += n & 1;
            }
            n >>= 1;
        }
        return count;
    }

    static int setBitsStr(String str) {
        int count = 0;
        for (int i = 0; i < str.length(); ++i) {
            int temp = Integer.valueOf(str.charAt(i));
            count += setBitsInt(temp);
        }
        return count;
    }

}
