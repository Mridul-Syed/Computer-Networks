

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.io.*;

public class Client {

    public static void main(String[] args) {

        try {
            Socket soc = new Socket("127.0.0.1", 25);

            //BufferedReader in = new BufferedReader(new InputStreamReader(System.in)); //from System
            ObjectInputStream sin = new ObjectInputStream(soc.getInputStream()); //from client
            ObjectOutputStream sout = new ObjectOutputStream(soc.getOutputStream()); //to client

            Frame outFrame = new Frame(0.15f, "data", 15, true);

            String tmp_str = Float.toString(outFrame.header);
            String[] tmp_str_2 = tmp_str.split("[.]");
            int count = setBitsInt(outFrame.protocolID) + setBitsStr(outFrame.data) + setBitsInt(Integer.parseInt(tmp_str_2[0])) + setBitsInt(Integer.parseInt(tmp_str_2[1]));

            if (count % 2 == 0) {
              outFrame.tailer = false;
            }

            //sending to server
            System.out.println("Sending object to server...");
            sout.writeObject(outFrame);
            System.out.println("Header: " + outFrame.header + "\nData: " + outFrame.data + "\nProtocolID: " + outFrame.protocolID + "\nTailer: " + outFrame.tailer);
            System.out.println("Sent.");
            System.out.println();
            System.out.println("Total number of set bits: " + count);

            //receiving from server
            //Frame inFrame = (Frame)sin.readObject();
            //System.out.println("Return object from server: " + inFrame.header + " " + inFrame.data + " " + inFrame.protocolID + " " + inFrame.tailer);

            soc.close();
        } catch (Exception e) {
          System.out.println("Exception caught: " + e);
        }
    }

    static int setBitsInt(int n) {
        int count = 0;
        while (n != 0) {
            if (n > 0) {
                count += n & 1;
            }
            n >>= 1;
        }
        return count;
    }

    static int setBitsStr(String str) {
        int count = 0;
        for (int i = 0; i < str.length(); ++i) {
            int temp = Integer.valueOf(str.charAt(i));
            count += setBitsInt(temp);
        }
        return count;
    }

}
